exports.handler = async function (event) {
  return Promise.resolve({
    statusCode: 200,
    message: 'La lambda esta activa'
  });
};